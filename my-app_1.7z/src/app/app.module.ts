import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ApplicationRef } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import {CommonModule} from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';



import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';

import { GraphQLModule } from './graphql.module';

import { FormsModule } from '@angular/forms';

// ag-grid


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule,
    AgGridModule.withComponents([AgGridModule]),
    GraphQLModule

  ],
  providers: [],
  entryComponents: [AppComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
