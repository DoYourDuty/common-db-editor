import { logging } from 'protractor';
import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Apollo, gql } from 'apollo-angular';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-community';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import 'ag-grid-community/dist/styles/ag-theme-material.css';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
   editType: any;
  title = 'my-app';
  @ViewChild('agGrid') agGrid: AgGridAngular | undefined;

  defaultColDef = {
    flex: 1,
    minWidth: 200,
    resizable: true,
    floatingFilter: true,
    menuTabs: ['filterMenuTab'],
    editable: true,
    sortable: true,
    filter: true,

  };
  // valueSetter: quantityValueSetter

  //checkboxSelection: true
  columnDefs = [
    { field: 'address', headerCheckboxSelection: true,
    headerCheckboxSelectionFilteredOnly: true,
    checkboxSelection: true,},
    { field: 'city' },
    { field: 'companyName'},
    { field: 'contactName' },
    { field: 'contactTitle' },
    { field: 'country' },
    { field: 'customerId' },
    { field: 'fax' },
    { field: 'postalCode' },
    { field: 'region', cellEditor: 'agSelectCellEditor',
    cellEditorParams: {
      values: ['Edit', 'Delete'],
    }, },
    // { field: 'price'}
  ];

  rowClassRules = {
    'sick-days-warning': function (params: any) {
      var region = params.data.region;
      return  region === "Edit";
    },
    'sick-days-breach': 'data.region === "Delete"',
  };

  autoGroupColumnDef = {
    headerName: 'country',
    field: 'country',
    cellRenderer: 'agGroupCellRenderer',
    cellRendererParams: {
      checkbox: true,
      rowSelection: 'multiple'
    },
  };
  //,rowGroup: true

  rowData: any;

  rates: any[] | undefined;
  loading = true;
  error: any;

  // currentDataChangeList: changeList[] = [];

  private gridApi: any;
  private gridColumnApi: any;
  undoRedoCellEditingLimit: any;
  constructor(private http: HttpClient, private apollo: Apollo) {
    this.editType = 'fullRow';
    this.undoRedoCellEditingLimit = 100;
    // this.getRowData = this.getRowData.bind(this);
  }

  onGridReady(params:any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  onBtStopEditing() {
    this.gridApi.stopEditing();
  }

  onRemoveSelected()
  {
    var selectedRowData = this.gridApi.getSelectedRows();
    selectedRowData.forEach(function (value: any) {
      value.region = (value.region === "Delete"? "Edit": "Delete");
      console.log(value.region);
    });
    //console.log(selectedRowData.length);
    this.gridApi.applyTransaction({ update: selectedRowData });
    //this.gridApi.updateRowData({ update: selectedRowData });
    // var params = {
    //   force: false,
    //   suppressFlash: false,
    // };
    // this.gridApi.refreshCells(params);
  }

  onEditRow(event: any){
    //event.data.region = "Edit";
    console.log(event);
  }

  onBtStartEditing() {
    this.gridApi.setFocusedCell(2, 'country');
    this.gridApi.startEditingCell({
      rowIndex: 2,
      colKey: 'country',
    });
  }

  ngOnInit() {
    //   this.http.post<data>('http://localhost:5827/graphql/', '{"query": "{\n  regions {\n    regionDescription\n    regionId\n  }\n}\n","variables": {}}').subscribe({
    //   next: albums =>{
    //     this.rowData=albums.regions
    //   }
    // });

    this.apollo
      .watchQuery({
        query: gql`
          query {
            customers {
              postalCode
              region
              address
              city
              companyName
              contactName
              contactTitle
              country
              customerId
              fax
              phone
            }
          }
        `,
      })
      .valueChanges.subscribe((result: any) => {
        this.rowData = this.deepCopy(result?.data?.customers);
        this.loading = result.loading;
        this.error = result.error;
      });

    //   console.log(this.rowData);
    // this.rowData = this.getRowData();
    //   console.log(this.rowData);
    function myRowClickedHandler(event: any) {
      // console.log('The row was clicked');
    }

    var myGrid = document.querySelector('#myGrid');


  }

   deepCopy(obj: any) {
    var copy: any;

    // Handle the 3 simple types, and null or undefined
    if (null == obj || "object" != typeof obj) return obj;

    // Handle Date
    if (obj instanceof Date) {
        copy = new Date();
        copy.setTime(obj.getTime());
        return copy;
    }

    // Handle Array
    if (obj instanceof Array) {
        copy = [];
        for (var i = 0, len = obj.length; i < len; i++) {
            copy[i] = this.deepCopy(obj[i]);
        }
        return copy;
    }

    // Handle Object
    if (obj instanceof Object) {
        copy = {};
        for (var attr in obj) {
            if (obj.hasOwnProperty(attr)) copy[attr] = this.deepCopy(obj[attr]);
        }
        return copy;
    }

    throw new Error("Unable to copy obj! Its type isn't supported.");
}


      // getRowData() {
      //   var rowDataLocal : any;
      //   rowDataLocal = {...this.rowData};
      //   return rowDataLocal;
      // }





  onCellClicked(event: any) {
    // console.log(event);
  }

  getSelectedRows() {
    const selectedNodes = this.agGrid?.api.getSelectedNodes();
    const selectedData = selectedNodes?.map((node) => node.data);
    const selectedDataStringPresentation = selectedData
      ?.map((node) => node.customerId + ' ' + node.companyName)
      .join(', ');

    alert(`Selected nodes: ${selectedDataStringPresentation}`);
  }
}



function quantityValueSetter(params:any): any {
  console.log(params);
  params.data.city = params.newValue;
  }

export interface data {
  regions: region[];
}

export interface region {
  regionDescription: string;
  regionId: number;
}

export interface changeList{
  id:string;
  status:string;
}
